#!/bin/bash

cur_day="[ $(date) ]"

echo "$cur_day Hello, task2!"
