#!/bin/bash

echo "Hello World"
printf "exit code : "
echo $? 
