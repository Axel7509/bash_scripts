#!/sbin/bash

echo hello world!

echo -e "Exit code: $?\n"
